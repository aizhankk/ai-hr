create view v_candidate_rankings
            (job_posting_id, job_title, company_name, first_name, last_name, email, application_id, application_status,
             matching_score, rank_position, skills_matched, skills_missing, video_overall_score, confidence_score,
             emotional_tone_score, applied_at)
as
SELECT jp.id            AS job_posting_id,
       jp.title         AS job_title,
       rp.company_name,
       cp.first_name,
       cp.last_name,
       u.email,
       a.id             AS application_id,
       a.status         AS application_status,
       ara.matching_score,
       ara.rank_position,
       ara.skills_matched,
       ara.skills_missing,
       va.overall_score AS video_overall_score,
       va.confidence_score,
       va.emotional_tone_score,
       a.applied_at
FROM aihr.applications a
         JOIN aihr.job_postings jp ON jp.id = a.job_posting_id
         JOIN aihr.recruiter_profiles rp ON rp.id = jp.recruiter_id
         JOIN aihr.candidate_profiles cp ON cp.id = a.candidate_id
         JOIN aihr.users u ON u.id = cp.user_id
         LEFT JOIN aihr.ai_resume_analyses ara ON ara.application_id = a.id
         LEFT JOIN aihr.video_interviews vi ON vi.application_id = a.id
         LEFT JOIN aihr.video_analyses va ON va.video_interview_id = vi.id
ORDER BY ara.matching_score DESC NULLS LAST;

alter table v_candidate_rankings
    owner to postgres;

