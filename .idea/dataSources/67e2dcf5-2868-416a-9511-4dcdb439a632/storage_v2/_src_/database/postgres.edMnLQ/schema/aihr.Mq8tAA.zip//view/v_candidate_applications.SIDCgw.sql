create view v_candidate_applications
            (application_id, candidate_id, first_name, last_name, job_title, company_name, status, applied_at,
             matching_score, video_status, video_score)
as
SELECT a.id             AS application_id,
       cp.id            AS candidate_id,
       cp.first_name,
       cp.last_name,
       jp.title         AS job_title,
       rp.company_name,
       a.status,
       a.applied_at,
       ara.matching_score,
       vi.status        AS video_status,
       va.overall_score AS video_score
FROM aihr.applications a
         JOIN aihr.candidate_profiles cp ON cp.id = a.candidate_id
         JOIN aihr.job_postings jp ON jp.id = a.job_posting_id
         JOIN aihr.recruiter_profiles rp ON rp.id = jp.recruiter_id
         LEFT JOIN aihr.ai_resume_analyses ara ON ara.application_id = a.id
         LEFT JOIN aihr.video_interviews vi ON vi.application_id = a.id
         LEFT JOIN aihr.video_analyses va ON va.video_interview_id = vi.id;

alter table v_candidate_applications
    owner to postgres;

